import express from "express";
import healthRouter from "./routes/health.js"
import authRouter from "./modules/auth/auth.routes.js"
import orgRouter from "./modules/organization/organization.routes.js"
import projectRouter from "./modules/project/project.routes.js"
import taskRouter from "./modules/task/task.routes.js"
import { errorHandler } from "./middlewares/error.middleware.js"
import cors from "cors"

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use("/health",healthRouter);
app.use("/api/v1/auth",authRouter);
app.use("/api/v1/org",orgRouter);
app.use("/api/v1/projects",projectRouter);
app.use("/api/v1/tasks",taskRouter);
app.use(errorHandler);

export default app;